<?php

namespace Database\Factories;

use App\Models\Utiliti;
use Illuminate\Database\Eloquent\Factories\Factory;

class UtilitiFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Utiliti::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
