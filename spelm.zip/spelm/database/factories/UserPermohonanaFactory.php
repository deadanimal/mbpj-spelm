<?php

namespace Database\Factories;

use App\Models\UserPermohonana;
use Illuminate\Database\Eloquent\Factories\Factory;

class UserPermohonanaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = UserPermohonana::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
