<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class EkedatanganSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
