<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class TuntutanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
