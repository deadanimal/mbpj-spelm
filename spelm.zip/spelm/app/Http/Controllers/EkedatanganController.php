<?php

namespace App\Http\Controllers;

use App\Models\Ekedatangan;
use Illuminate\Http\Request;

class EkedatanganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Ekedatangan  $ekedatangan
     * @return \Illuminate\Http\Response
     */
    public function show(Ekedatangan $ekedatangan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Ekedatangan  $ekedatangan
     * @return \Illuminate\Http\Response
     */
    public function edit(Ekedatangan $ekedatangan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Ekedatangan  $ekedatangan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ekedatangan $ekedatangan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Ekedatangan  $ekedatangan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ekedatangan $ekedatangan)
    {
        //
    }
}
